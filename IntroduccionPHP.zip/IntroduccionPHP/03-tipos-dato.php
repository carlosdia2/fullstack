<?php include 'includes/header.php';

// Boolean
$logueado = true;
var_dump($logueado);

// Enteros
$numero = 200;
var_dump($numero);

// Floats
$float = 200.5;
var_dump($float);

// Strings
$nombre = "Juan";
var_dump($nombre);

$array = [];
var_dump($array);


include 'includes/footer.php';