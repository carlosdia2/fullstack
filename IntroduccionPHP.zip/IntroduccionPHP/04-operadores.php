<?php include 'includes/header.php';

$numero1 = 20;
$numero2 = 10;

// Sumar
echo $numero1 + $numero2;

// Resta
echo $numero1 - $numero2;

echo "<br>";

// Multiplicar
echo $numero1 * $numero2;

// Dividir
echo $numero1 / $numero2;

// Multiplicar cierta cantidad de veces
echo 2 ** 3;


include 'includes/footer.php';