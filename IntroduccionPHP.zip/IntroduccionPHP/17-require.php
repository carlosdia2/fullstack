<?php include 'includes/header.php';

require 'funciones.php';

iniciarApp();



include 'includes/footer.php';