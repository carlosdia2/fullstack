<?php

function iniciarApp() {
    echo "Iniciando nuestra app...";
}