// alert("hola mundo")

// creamos una variable dinamica, le damos el valor con = 

let producto = "Nombre del producto";

let disponible;


disponible = true;

disponible = "no hay producto";

// let camiseta = "red";
// let pantalon = "yellow";
// let zapatos = "blue";

let camiseta = "red",
    pantalon = "yellow",
    zapatos;

    console.log("hola", camiseta);

    zapatos= "negros";

    console.log("color de camiseta:", camiseta);
    console.log("color de pantalon:", pantalon);
    console.log("color de zapatos:", zapatos);

    let variable = true;

    const variableConstante = "si";

    console.log("constante variable: ", variableConstante);
